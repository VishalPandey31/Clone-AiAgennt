import mongoose from "mongoose";

function connect() {
    const uri = process.env.MONGODB_URI;

    if (!uri) {
        console.error("❌ ERROR: MONGODB_URI is missing in your .env file");
        return;
    }

    return mongoose.connect(uri)
        .then(() => {
            console.log("✅ Connected to MongoDB");
        })
        .catch(err => {
            console.error("❌ MongoDB Connection Error:", err.message);
        });
}

export default connect;