import mongoose from "mongoose";

function connect() {
    const uri = process.env.MONGODB_URI;

    if (!uri) {
        console.error("❌ ERROR: MONGODB_URI is missing in your .env file");
        process.exit(1);
    }

    console.log("Attempting to connect to MongoDB...");
    // Log the URI with password masked to verify it's being read
    const maskedUri = uri.replace(/:\/\/([^:]+):([^@]+)@/, '://$1:****@');
    console.log(`URI: ${maskedUri}`);

    return mongoose.connect(uri)
        .then(() => {
            console.log("✅ Connected to MongoDB");
        })
        .catch(err => {
            console.error("❌ MongoDB Connection Error:", err.message);
            process.exit(1); // Exit process to signal deployment failure
        });
}

export default connect;