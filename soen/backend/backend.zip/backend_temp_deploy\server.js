import 'dotenv/config';
import http from 'http';
import app from './app.js';
import { Server } from 'socket.io';
import jwt from 'jsonwebtoken';
import mongoose from 'mongoose';
import projectModel from './models/project.model.js';
import sessionModel from './models/session.model.js';
import messageModel from './models/message.model.js';
import { generateResult } from './services/ai.service.js';

const port = process.env.PORT || 3000;



const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: '*'
    }
});


io.use(async (socket, next) => {

    try {

        const token = socket.handshake.auth?.token || socket.handshake.headers.authorization?.split(' ')[1];
        const projectId = socket.handshake.query.projectId;

        if (!mongoose.Types.ObjectId.isValid(projectId)) {
            return next(new Error('Invalid projectId'));
        }


        socket.project = await projectModel.findById(projectId);


        if (!token) {
            return next(new Error('Authentication error'))
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        if (!decoded) {
            return next(new Error('Authentication error'))
        }


        socket.user = decoded;

        next();

    } catch (error) {
        next(error)
    }

})


// Rate limiting
let lastAiCall = 0;

io.on('connection', async socket => {
    socket.roomId = socket.project._id.toString()


    console.log('a user connected');

    // Create a new session
    try {
        const session = await sessionModel.create({
            projectId: socket.project._id,
            userId: socket.user.id // Assuming socket.user contains the decoded token payload with id
        });
        socket.sessionId = session._id.toString();
    } catch (err) {
        console.error("Error creating session:", err);
    }



    socket.join(socket.roomId);

    socket.on('project-message', async data => {

        const message = data.message;

        const aiIsPresentInMessage = message.includes('@ai');
        socket.broadcast.to(socket.roomId).emit('project-message', data)

        try {
            await messageModel.create({
                projectId: socket.project._id,
                sender: data.sender,
                message: data.message,
                timestamp: data.timestamp || new Date()
            });
        } catch (err) {
            console.error("Error saving message:", err);
        }

        if (aiIsPresentInMessage) {

            if (Date.now() - lastAiCall < 500) {
                io.to(socket.roomId).emit('project-message', {
                    message: JSON.stringify({ text: "Please wait a moment before sending another request." }),
                    sender: {
                        _id: 'ai',
                        email: 'AI'
                    }
                })
                return;
            }
            lastAiCall = Date.now();

            try {
                const prompt = message.replace('@ai', '').trim();

                // Rule: Exact greetings
                const lowerPrompt = prompt.toLowerCase();
                if (lowerPrompt === '' || lowerPrompt === 'hi' || lowerPrompt === 'hello') {
                    io.to(socket.roomId).emit('project-message', {
                        message: JSON.stringify({ text: "Hi 👋 How can I help you?" }),
                        sender: {
                            _id: 'ai',
                            email: 'AI'
                        }
                    })
                    return;
                }

                // Retry logic
                let attempts = 0;
                const maxAttempts = 2; // Reduced from 10
                let result = null;

                while (attempts < maxAttempts) {
                    try {
                        result = await generateResult(prompt);
                        break; // Success, exit loop
                    } catch (err) {
                        attempts++;
                        if (err.message && (err.message.includes('429') || err.message.includes('Quota exceeded'))) {
                            if (attempts < maxAttempts) {
                                // Silently retry
                                await new Promise(resolve => setTimeout(resolve, 5000)); // Wait 5s
                                continue;
                            }
                        }
                        throw err; // Re-throw if not 429 or max attempts reached
                    }
                }

                const aiResponse = {
                    message: result,
                    sender: {
                        _id: 'ai',
                        email: 'AI'
                    },
                    timestamp: new Date().toISOString()
                };
                io.to(socket.roomId).emit('project-message', aiResponse);

                await messageModel.create({
                    projectId: socket.project._id,
                    sender: aiResponse.sender,
                    message: aiResponse.message,
                    timestamp: aiResponse.timestamp
                });
            } catch (err) {
                console.error("AI Generation Error:", err);
                // Rule: Never show system messages like "Rate Limit Exceeded"
                // Rule: Reply politely
                const userMessage = "Please wait a moment before sending another request.";

                io.to(socket.roomId).emit('project-message', {
                    message: JSON.stringify({ text: userMessage }),
                    sender: {
                        _id: 'ai',
                        email: 'AI'
                    }
                })
            }
        }


    })

    socket.on('project-activity', data => {
        // Broadcast activity (like "User A opened File X") to everyone else in the room
        socket.broadcast.to(socket.roomId).emit('project-activity', data);
    });

    socket.on('disconnect', async () => {
        console.log('user disconnected');
        socket.leave(socket.roomId)

        if (socket.sessionId) {
            try {
                const logoutTime = new Date();
                const session = await sessionModel.findById(socket.sessionId);
                if (session) {
                    const duration = Math.round((logoutTime - session.loginTime) / 1000); // duration in seconds
                    await sessionModel.findByIdAndUpdate(socket.sessionId, {
                        logoutTime,
                        duration
                    });
                }
            } catch (err) {
                console.error("Error updating session:", err);
            }
        }
    });
});




import connect from './db/db.js';

const startServer = async () => {
    await connect();

    server.listen(port, () => {
        console.log(`Server is running on port ${port}`);
    });
}

startServer();