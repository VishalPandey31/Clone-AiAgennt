import mongoose from "mongoose";

const connect = async () => {
    // We stick to env var for security, but follow the user's connection style
    const uri = process.env.MONGODB_URI;

    if (!uri) {
        console.error("❌ ERROR: MONGODB_URI is missing (Check .env)");
        process.exit(1);
    }

    /* 
       User requested style:
       mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
       (Note: These options are default in Mongoose 6+, but including for compliance with request if needed, 
        though usually better to omit to avoid deprecation warnings. We will omit them for Mongoose 8+ compat)
    */

    console.log("Connecting to MongoDB Atlas...");

    try {
        await mongoose.connect(uri);
        console.log("✅ MongoDB Atlas connected successfully!");
    } catch (err) {
        console.error("❌ MongoDB Atlas connection error:", err);
        process.exit(1);
    }
}

export default connect;