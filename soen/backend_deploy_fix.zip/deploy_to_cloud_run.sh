#!/bin/bash
echo "Starting deployment to Cloud Run..."
gcloud run deploy backend \
  --source . \
  --region asia-south1 \
  --platform managed \
  --allow-unauthenticated

echo "Deployment command finished."
